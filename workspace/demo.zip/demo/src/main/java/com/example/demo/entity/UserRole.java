package com.example.demo.entity;

public enum UserRole {
	member, vendor, admin
}